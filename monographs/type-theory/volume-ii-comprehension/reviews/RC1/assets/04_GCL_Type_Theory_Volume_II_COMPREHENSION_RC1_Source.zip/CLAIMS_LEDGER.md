# Claims Ledger — Volume II: COMPREHENSION

| ID | Claim | Status | Exact scope | Evidence/source |
|---|---|---|---|---|
| V2-C001 | A well-formed type family may depend on an earlier term in a telescope. | definition/theorem | COMP-0 | Ch. 1 |
| V2-C002 | Dependent context order can be semantically significant. | theorem/structural fact | COMP-0 | Ch. 1; Plates 2–3 |
| V2-C003 | Generalized substitution rewrites the subject and all dependent trailing declarations. | theorem | COMP-0 | Ch. 2; Lab 2 |
| V2-C004 | Weakening is admissible when formation and freshness/dependency side conditions hold. | theorem | COMP-0 | Ch. 1 |
| V2-C005 | `Π(x:A).B` specializes to the ordinary arrow presentation when the family is constant in `x`. | definitional specialization | COMP-ΠΣ presentation | Ch. 3; Plate 8 |
| V2-C006 | Dependent application specializes its codomain by substitution. | typing rule + theorem case | COMP-ΠΣ | Ch. 3; Lab 3 |
| V2-C007 | Principal Π-beta reduction preserves the stated result type. | theorem | COMP-ΠΣ principal case | Ch. 3 |
| V2-C008 | `Σ(x:A).B` specializes to ordinary product in the constant-family presentation. | definitional specialization | COMP-ΠΣ presentation | Ch. 4; Plate 11 |
| V2-C009 | The second projection of a dependent pair has type specialized by the first projection. | typing rule | COMP-ΠΣ | Ch. 4; Plate 12; Lab 4 |
| V2-C010 | Adjacent exchange is conditional on independence, not freely admissible. | structural proposition | COMP | Ch. 5; Plate 14 |
| V2-C011 | The admitted `Fin` constructors exclude constructor/index combinations inconsistent with their result indices. | canonical-forms/inversion result | selected COMP-I `Fin` | Ch. 6; Lab 6 |
| V2-C012 | The admitted vector constructors encode vector length in the result index. | canonical-forms/inversion result | selected COMP-I `Vec` | Ch. 7; Lab 7 |
| V2-C013 | A head operation on `Vec(A,succ(n))` needs no nil branch in the selected family. | formal example | selected COMP-I `Vec` | Ch. 8; Lab 8 |
| V2-C014 | `Vec(A,n)` together with `Fin(n)` suffices for a bounds-indexed lookup example. | formal/computed example | selected COMP-I fragment | Ch. 8; Lab 8 |
| V2-C015 | Definitional equality is generated only by admitted computation/congruence and does not stand for arbitrary mathematical equality. | claim boundary | all fragments | Ch. 9 |
| V2-C016 | The restricted bidirectional checker is sound for the declarative rules it implements. | theorem + regression evidence | COMP-CHECK subset | Ch. 10; Lab 10 |
| V2-C017 | The teaching checker is intentionally incomplete for arbitrary declarative equality/inference. | claim boundary | COMP-CHECK | Chs. 9–11 |
| V2-C018 | A sophisticated elaborator can remain outside the trusted validity kernel when the emitted explicit core is independently checked. | scoped trust-boundary proposition | elaboration architecture | Ch. 11; Lab 11 |
| V2-C019 | The toy `U0`/`El` code language demonstrates coding/decoding without admitting `Type : Type`. | formal/computed example, not universe metatheory | universe preview only | Ch. 12; Lab 12 |
| V2-C020 | Categorical comprehension is used as a semantic organization of dependency, not as literal identity between syntax and a category. | interpretive boundary | Ch. 13 semantic reading | Ch. 13; Plate 38 |
| V2-C021 | Indexed types guarantee only invariants encoded and preserved within their trust assumptions. | bounded systems claim | whole volume | Chs. 6–14; Plate 41 |
| V2-C022 | The series title remains a research thesis; Volume II supports a scoped “formation rules build computational worlds” thesis, not a universal theorem. | research hypothesis boundary | series | front matter; Ch. 14 |
| V2-C023 | Volume II does not claim strong normalization, global canonicity, general positivity checking, full universe consistency, complete dependent inference, or propositional equality/transport. | explicit non-claim | all | theorem audit; Chs. 7, 9–12 |
