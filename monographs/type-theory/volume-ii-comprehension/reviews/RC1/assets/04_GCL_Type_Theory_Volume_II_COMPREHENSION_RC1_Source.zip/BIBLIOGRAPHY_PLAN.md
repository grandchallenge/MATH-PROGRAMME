# Bibliography Plan — Volume II: COMPREHENSION

## Foundational / primary anchors

- Per Martin-Löf, *Intuitionistic Type Theory* (1984): judgmental dependent type theory.
- N. G. de Bruijn, AUTOMATH (1970): early machine-oriented dependent formal language.
- John Cartmell, contextual categories / generalised algebraic theories (1978 thesis; 1986 journal article).
- Thierry Coquand and Gérard Huet, Calculus of Constructions (1988).
- Peter Dybjer, inductive families (1994).

## Modern/expository/semantic anchors

- Nordström, Petersson, Smith (1990).
- Martin Hofmann (1997).
- Bart Jacobs (1999).
- Pierce (2002), Harper (2016) for programming-language context.

## Discipline

Priority words such as “first” or “introduced” are avoided unless independently verified. Universe and identity-type material is explicitly a preview, not a historical completeness claim.
