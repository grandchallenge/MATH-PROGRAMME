# Volume II — COMPREHENSION: How Computational Worlds Are Built

Internal Release Candidate 1 of Volume II in **TYPE THEORY — The Grand Unified Theory of Computation**.

The source is self-contained and governed by `docs/monographs/type-theory-series/SERIES_HANDOFF.md`. Build with LuaLaTeX; run `python labs/run_all.py` for executable evidence. The RC1 state is internally complete for composition/publication preparation, but is **not** represented as independently refereed. `WORKSET_STATE.json` is the durable resume point.
