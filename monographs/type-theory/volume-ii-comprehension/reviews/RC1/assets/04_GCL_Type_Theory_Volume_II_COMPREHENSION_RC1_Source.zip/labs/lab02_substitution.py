from __future__ import annotations
import json
from pathlib import Path
from comp_core import *
OUT=Path(__file__).resolve().parents[1]/"evidence"
OUT.mkdir(exist_ok=True)
def emit(name,data):
    p=OUT/name
    p.write_text(json.dumps(data,indent=2,sort_keys=True)+"\n")
    print(json.dumps(data,indent=2,sort_keys=True))
delta=(("i",FinT(Var("n"))),("j",FinT(Succ(Var("n")))))
out=subst_context(delta,"n",NatLit(3))
expected=(("i",FinT(NatLit(3))),("j",FinT(Succ(NatLit(3)))))
expr=FinT(Succ(Var('x')))
lhs=expr.subst('x',NatLit(1)).subst('y',NatLit(2))
rhs=expr.subst('y',NatLit(2)).subst('x',NatLit(1).subst('y',NatLit(2)))
data={"context_substitution":out==expected,"composition_case":lhs==rhs}
assert all(data.values()); emit('lab02_substitution.json',data)
