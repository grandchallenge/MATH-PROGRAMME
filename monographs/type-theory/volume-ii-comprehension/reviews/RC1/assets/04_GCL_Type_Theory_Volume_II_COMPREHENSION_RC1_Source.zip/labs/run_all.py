#!/usr/bin/env python3
from pathlib import Path
import json, runpy, traceback
ROOT=Path(__file__).resolve().parents[1]
LAB=ROOT/"labs"
results=[]
for p in sorted(LAB.glob("lab[0-9][0-9]_*.py")):
    try:
        runpy.run_path(str(p),run_name="__main__")
        results.append({"lab":p.name,"ok":True})
    except Exception as e:
        results.append({"lab":p.name,"ok":False,"error":repr(e)})
        traceback.print_exc()
report={"volume":"II","labs":results,"passed":sum(r["ok"] for r in results),"total":len(results),"all_pass":all(r["ok"] for r in results)}
(ROOT/"evidence"/"PUBLICATION_REGRESSION.json").write_text(json.dumps(report,indent=2)+"\n")
print(json.dumps(report,indent=2))
raise SystemExit(0 if report["all_pass"] else 1)
