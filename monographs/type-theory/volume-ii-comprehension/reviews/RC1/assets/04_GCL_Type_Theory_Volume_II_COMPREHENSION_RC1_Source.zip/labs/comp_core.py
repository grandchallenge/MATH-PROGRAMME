from __future__ import annotations
from dataclasses import dataclass
from typing import Tuple, Dict, Any

class Term:
    def subst(self, x: str, a: 'Term') -> 'Term': raise NotImplementedError
    def fv(self) -> set[str]: return set()

@dataclass(frozen=True)
class Var(Term):
    name: str
    def subst(self,x,a): return a if self.name==x else self
    def fv(self): return {self.name}
    def __str__(self): return self.name

@dataclass(frozen=True)
class NatLit(Term):
    n: int
    def subst(self,x,a): return self
    def __str__(self): return str(self.n)

@dataclass(frozen=True)
class BoolLit(Term):
    value: bool
    def subst(self,x,a): return self
    def __str__(self): return 'true' if self.value else 'false'

@dataclass(frozen=True)
class Succ(Term):
    t: Term
    def subst(self,x,a): return Succ(self.t.subst(x,a))
    def fv(self): return self.t.fv()
    def __str__(self): return f'succ({self.t})'

@dataclass(frozen=True)
class Lam(Term):
    var: str
    body: Term
    def fv(self): return self.body.fv()-{self.var}
    def subst(self,x,a):
        if self.var==x: return self
        if self.var in a.fv():
            z=fresh(self.var, self.body.fv()|a.fv()|{x})
            renamed=self.body.subst(self.var,Var(z))
            return Lam(z,renamed.subst(x,a))
        return Lam(self.var,self.body.subst(x,a))
    def __str__(self): return f'(lambda {self.var}. {self.body})'

@dataclass(frozen=True)
class App(Term):
    f: Term; a: Term
    def subst(self,x,a): return App(self.f.subst(x,a),self.a.subst(x,a))
    def fv(self): return self.f.fv()|self.a.fv()
    def __str__(self): return f'({self.f} {self.a})'

@dataclass(frozen=True)
class Pair(Term):
    fst: Term; snd: Term
    def subst(self,x,a): return Pair(self.fst.subst(x,a),self.snd.subst(x,a))
    def fv(self): return self.fst.fv()|self.snd.fv()
    def __str__(self): return f'<{self.fst},{self.snd}>'

@dataclass(frozen=True)
class Fst(Term):
    p: Term
    def subst(self,x,a): return Fst(self.p.subst(x,a))
    def fv(self): return self.p.fv()
    def __str__(self): return f'fst({self.p})'

@dataclass(frozen=True)
class Snd(Term):
    p: Term
    def subst(self,x,a): return Snd(self.p.subst(x,a))
    def fv(self): return self.p.fv()
    def __str__(self): return f'snd({self.p})'

class Ty:
    def subst(self,x:str,a:Term)->'Ty': return self
    def fv(self)->set[str]: return set()

@dataclass(frozen=True)
class NatT(Ty):
    def __str__(self): return 'Nat'
@dataclass(frozen=True)
class BoolT(Ty):
    def __str__(self): return 'Bool'
@dataclass(frozen=True)
class FinT(Ty):
    n: Term
    def subst(self,x,a): return FinT(self.n.subst(x,a))
    def fv(self): return self.n.fv()
    def __str__(self): return f'Fin({self.n})'
@dataclass(frozen=True)
class VecT(Ty):
    elem: Ty; n: Term
    def subst(self,x,a): return VecT(self.elem.subst(x,a), self.n.subst(x,a))
    def fv(self): return self.elem.fv()|self.n.fv()
    def __str__(self): return f'Vec({self.elem},{self.n})'
@dataclass(frozen=True)
class PiT(Ty):
    var: str; dom: Ty; cod: Ty
    def fv(self): return self.dom.fv() | (self.cod.fv()-{self.var})
    def subst(self,x,a):
        dom=self.dom.subst(x,a)
        if self.var==x: return PiT(self.var,dom,self.cod)
        if self.var in a.fv():
            z=fresh(self.var,self.cod.fv()|a.fv()|{x})
            cod=self.cod.subst(self.var,Var(z)).subst(x,a)
            return PiT(z,dom,cod)
        return PiT(self.var,dom,self.cod.subst(x,a))
    def __str__(self): return f'Pi({self.var}:{self.dom}).{self.cod}'
@dataclass(frozen=True)
class SigmaT(Ty):
    var: str; fst: Ty; snd: Ty
    def fv(self): return self.fst.fv() | (self.snd.fv()-{self.var})
    def subst(self,x,a):
        first=self.fst.subst(x,a)
        if self.var==x: return SigmaT(self.var,first,self.snd)
        if self.var in a.fv():
            z=fresh(self.var,self.snd.fv()|a.fv()|{x})
            snd=self.snd.subst(self.var,Var(z)).subst(x,a)
            return SigmaT(z,first,snd)
        return SigmaT(self.var,first,self.snd.subst(x,a))
    def __str__(self): return f'Sigma({self.var}:{self.fst}).{self.snd}'

Context=Tuple[Tuple[str,Ty],...]

def fresh(base:str, used:set[str])->str:
    if base not in used: return base
    i=1
    while f'{base}{i}' in used: i+=1
    return f'{base}{i}'

def lookup(ctx:Context,x:str)->Ty:
    for y,t in reversed(ctx):
        if y==x:return t
    raise KeyError(x)

def infer_base(ctx:Context,t:Term)->Ty:
    if isinstance(t,Var): return lookup(ctx,t.name)
    if isinstance(t,NatLit): return NatT()
    if isinstance(t,Succ):
        if infer_base(ctx,t.t)!=NatT(): raise TypeError('succ argument')
        return NatT()
    if isinstance(t,BoolLit): return BoolT()
    raise TypeError(f'cannot infer base term {t}')

def wf_type(ctx:Context,T:Ty)->bool:
    if isinstance(T,(NatT,BoolT)): return True
    if isinstance(T,FinT):
        try: return infer_base(ctx,T.n)==NatT()
        except (KeyError,TypeError): return False
    if isinstance(T,VecT):
        try: return wf_type(ctx,T.elem) and infer_base(ctx,T.n)==NatT()
        except (KeyError,TypeError): return False
    if isinstance(T,PiT): return wf_type(ctx,T.dom) and wf_type(ctx+((T.var,T.dom),),T.cod)
    if isinstance(T,SigmaT): return wf_type(ctx,T.fst) and wf_type(ctx+((T.var,T.fst),),T.snd)
    return False

def wf_context(ctx:Context)->bool:
    prefix=()
    seen=set()
    for x,T in ctx:
        if x in seen or not wf_type(prefix,T): return False
        prefix=prefix+((x,T),); seen.add(x)
    return True

def subst_context(delta:Context,x:str,a:Term)->Context:
    return tuple((y,T.subst(x,a)) for y,T in delta if y!=x)

def normalize(t:Term)->Term:
    if isinstance(t,App):
        f=normalize(t.f); a=normalize(t.a)
        if isinstance(f,Lam): return normalize(f.body.subst(f.var,a))
        return App(f,a)
    if isinstance(t,Fst):
        p=normalize(t.p)
        if isinstance(p,Pair): return normalize(p.fst)
        return Fst(p)
    if isinstance(t,Snd):
        p=normalize(t.p)
        if isinstance(p,Pair): return normalize(p.snd)
        return Snd(p)
    if isinstance(t,Succ): return Succ(normalize(t.t))
    if isinstance(t,Lam): return Lam(t.var,normalize(t.body))
    if isinstance(t,Pair): return Pair(normalize(t.fst),normalize(t.snd))
    return t

def term_eq(a:Term,b:Term)->bool: return normalize(a)==normalize(b)
def ty_eq(A:Ty,B:Ty)->bool:
    if type(A)!=type(B): return False
    if isinstance(A,(NatT,BoolT)): return True
    if isinstance(A,FinT): return term_eq(A.n,B.n)
    if isinstance(A,VecT): return ty_eq(A.elem,B.elem) and term_eq(A.n,B.n)
    if isinstance(A,PiT):
        return ty_eq(A.dom,B.dom) and ty_eq(A.cod, B.cod.subst(B.var,Var(A.var)))
    if isinstance(A,SigmaT):
        return ty_eq(A.fst,B.fst) and ty_eq(A.snd, B.snd.subst(B.var,Var(A.var)))
    return A==B

def synth(ctx:Context,t:Term)->Ty:
    if isinstance(t,(Var,NatLit,Succ,BoolLit)): return infer_base(ctx,t)
    if isinstance(t,App):
        F=synth(ctx,t.f)
        if not isinstance(F,PiT): raise TypeError('application of non-Pi')
        check(ctx,t.a,F.dom)
        return F.cod.subst(F.var,t.a)
    if isinstance(t,Fst):
        P=synth(ctx,t.p)
        if not isinstance(P,SigmaT): raise TypeError('fst of non-Sigma')
        return P.fst
    if isinstance(t,Snd):
        P=synth(ctx,t.p)
        if not isinstance(P,SigmaT): raise TypeError('snd of non-Sigma')
        return P.snd.subst(P.var,Fst(t.p))
    raise TypeError(f'cannot synthesize {t}')

def check(ctx:Context,t:Term,A:Ty)->bool:
    if isinstance(t,Lam) and isinstance(A,PiT):
        return check(ctx+((t.var,A.dom),),t.body,A.cod.subst(A.var,Var(t.var)))
    if isinstance(t,Pair) and isinstance(A,SigmaT):
        return check(ctx,t.fst,A.fst) and check(ctx,t.snd,A.snd.subst(A.var,t.fst))
    return ty_eq(synth(ctx,t),A)

def fin_values(n:int):
    return list(range(n))

def vec(*xs): return tuple(xs)
def lookup_vec(xs:tuple,i:int):
    if not (0<=i<len(xs)): raise IndexError(i)
    return xs[i]

# Tiny first-order elaboration constraints over strings.
def solve_constraints(constraints:list[tuple[str,str]])->dict[str,str]:
    subst:dict[str,str]={}
    def resolve(s):
        while s.startswith('?') and s in subst and subst[s]!=s: s=subst[s]
        return s
    queue=list(constraints)
    while queue:
        a,b=map(resolve,queue.pop(0))
        if a==b: continue
        if a.startswith('?'):
            if a in b: raise ValueError('occurs check')
            subst[a]=b; continue
        if b.startswith('?'):
            if b in a: raise ValueError('occurs check')
            subst[b]=a; continue
        # constructor decomposition for simple F(args)
        def split(s):
            if '(' not in s: return s,[]
            h,rest=s.split('(',1); rest=rest[:-1]
            depth=0; cur=''; parts=[]
            for ch in rest+',':
                if ch==',' and depth==0: parts.append(cur); cur=''; continue
                cur+=ch
                if ch=='(': depth+=1
                elif ch==')': depth-=1
            return h,parts
        ha,aa=split(a); hb,bb=split(b)
        if ha!=hb or len(aa)!=len(bb): raise ValueError(f'clash {a} != {b}')
        queue= list(zip(aa,bb))+queue
    return subst

CODES={
    'natC':'Nat','boolC':'Bool',
}
def decode_code(code:Any,level:int=0)->str:
    if isinstance(code,str):
        if code=='selfC': raise ValueError('self-code rejected at same level')
        return CODES[code]
    tag,*args=code
    if tag=='prodC': return f'({decode_code(args[0],level)} x {decode_code(args[1],level)})'
    if tag=='vecC': return f'Vec({decode_code(args[0],level)},{args[1]})'
    raise ValueError(code)
