from __future__ import annotations
import json
from pathlib import Path
from comp_core import *
OUT=Path(__file__).resolve().parents[1]/"evidence"
OUT.mkdir(exist_ok=True)
def emit(name,data):
    p=OUT/name
    p.write_text(json.dumps(data,indent=2,sort_keys=True)+"\n")
    print(json.dumps(data,indent=2,sort_keys=True))
mappings=[{"type_former":"Pi","logical_preview":"universal/implication shape","status":"preview"},{"type_former":"Sigma","logical_preview":"existential/conjunction-with-dependency shape","status":"preview"},{"type_former":"Empty","logical_preview":"absurdity shape","status":"preview"}]
data={"mappings":mappings,"all_marked_preview":all(m['status']=='preview' for m in mappings)}
assert data['all_marked_preview']; emit('lab14_threshold.json',data)
