from __future__ import annotations
import json
from pathlib import Path
from comp_core import *
OUT=Path(__file__).resolve().parents[1]/"evidence"
OUT.mkdir(exist_ok=True)
def emit(name,data):
    p=OUT/name
    p.write_text(json.dumps(data,indent=2,sort_keys=True)+"\n")
    print(json.dumps(data,indent=2,sort_keys=True))
S=SigmaT('n',NatT(),FinT(Var('n')))
p=Pair(NatLit(2),Var('i')); ctx=(("i",FinT(NatLit(2))),)
assert check(ctx,p,S)
ctx2=ctx+(("p",S),)
t2=synth(ctx2,Snd(Var('p')))
data={"pair_checks":True,"snd_specializes":str(t2)=="Fin(fst(p))","fst_beta":str(normalize(Fst(p)))=='2',"snd_beta":str(normalize(Snd(p)))=='i'}
assert all(data.values()); emit('lab04_sigma.json',data)
