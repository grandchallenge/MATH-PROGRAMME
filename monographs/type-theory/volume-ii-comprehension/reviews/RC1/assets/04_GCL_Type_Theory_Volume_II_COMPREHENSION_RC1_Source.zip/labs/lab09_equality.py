from __future__ import annotations
import json
from pathlib import Path
from comp_core import *
OUT=Path(__file__).resolve().parents[1]/"evidence"
OUT.mkdir(exist_ok=True)
def emit(name,data):
    p=OUT/name
    p.write_text(json.dumps(data,indent=2,sort_keys=True)+"\n")
    print(json.dumps(data,indent=2,sort_keys=True))
redex=App(Lam('x',Succ(Var('x'))),NatLit(0))
A=VecT(NatT(),redex); B=VecT(NatT(),Succ(NatLit(0)))
data={"beta_index_equal":ty_eq(A,B),"syntactic_pressure_case":"n+0 not reduced because addition is outside core"}
assert data['beta_index_equal']; emit('lab09_equality.json',data)
