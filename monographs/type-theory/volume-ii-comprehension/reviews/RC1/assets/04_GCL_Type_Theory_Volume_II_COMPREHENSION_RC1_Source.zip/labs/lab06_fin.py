from __future__ import annotations
import json
from pathlib import Path
from comp_core import *
OUT=Path(__file__).resolve().parents[1]/"evidence"
OUT.mkdir(exist_ok=True)
def emit(name,data):
    p=OUT/name
    p.write_text(json.dumps(data,indent=2,sort_keys=True)+"\n")
    print(json.dumps(data,indent=2,sort_keys=True))
counts={str(n):len(fin_values(n)) for n in range(6)}
data={"counts":counts,"zero_empty":fin_values(0)==[],"n_equals_count":all(int(k)==v for k,v in counts.items())}
assert data['zero_empty'] and data['n_equals_count']; emit('lab06_fin.json',data)
