from __future__ import annotations
import json
from pathlib import Path
from comp_core import *
OUT=Path(__file__).resolve().parents[1]/"evidence"
OUT.mkdir(exist_ok=True)
def emit(name,data):
    p=OUT/name
    p.write_text(json.dumps(data,indent=2,sort_keys=True)+"\n")
    print(json.dumps(data,indent=2,sort_keys=True))
xs=vec('a','b','c'); results=[lookup_vec(xs,i) for i in fin_values(len(xs))]
data={"results":results,"all_in_range":results==list(xs),"empty_index_space":len(fin_values(0))==0}
assert data['all_in_range'] and data['empty_index_space']; emit('lab08_lookup.json',data)
