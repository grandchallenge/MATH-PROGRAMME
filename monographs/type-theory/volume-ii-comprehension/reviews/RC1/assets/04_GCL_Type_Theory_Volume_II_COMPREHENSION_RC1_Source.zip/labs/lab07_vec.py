from __future__ import annotations
import json
from pathlib import Path
from comp_core import *
OUT=Path(__file__).resolve().parents[1]/"evidence"
OUT.mkdir(exist_ok=True)
def emit(name,data):
    p=OUT/name
    p.write_text(json.dumps(data,indent=2,sort_keys=True)+"\n")
    print(json.dumps(data,indent=2,sort_keys=True))
vectors=[vec(),vec('a'),vec('a','b'),vec('a','b','c')]
data={"lengths":[len(v) for v in vectors],"nil_index_zero":len(vectors[0])==0,"cons_increments":all(len(vectors[i+1])==len(vectors[i])+1 for i in range(3))}
assert data['nil_index_zero'] and data['cons_increments']; emit('lab07_vec.json',data)
