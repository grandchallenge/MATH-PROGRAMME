from __future__ import annotations
import json
from pathlib import Path
from comp_core import *
OUT=Path(__file__).resolve().parents[1]/"evidence"
OUT.mkdir(exist_ok=True)
def emit(name,data):
    p=OUT/name
    p.write_text(json.dumps(data,indent=2,sort_keys=True)+"\n")
    print(json.dumps(data,indent=2,sort_keys=True))
examples={"fixed_function":{"S":True,"D":True},"dependent_result":{"S":False,"D":True},"indexed_vector":{"S":False,"D":True}}
data={"worlds":examples,"D_strictly_more_direct_examples":sum(1 for v in examples.values() if v['D'] and not v['S'])}
assert data['D_strictly_more_direct_examples']==2; emit('lab13_worlds.json',data)
