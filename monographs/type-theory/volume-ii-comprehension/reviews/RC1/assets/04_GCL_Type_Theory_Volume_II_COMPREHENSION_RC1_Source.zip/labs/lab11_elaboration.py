from __future__ import annotations
import json
from pathlib import Path
from comp_core import *
OUT=Path(__file__).resolve().parents[1]/"evidence"
OUT.mkdir(exist_ok=True)
def emit(name,data):
    p=OUT/name
    p.write_text(json.dumps(data,indent=2,sort_keys=True)+"\n")
    print(json.dumps(data,indent=2,sort_keys=True))
s1=solve_constraints([('?a','Nat'),('Vec(?a,2)','Vec(Nat,2)')])
occurs=False
try: solve_constraints([('?a','Pi(Nat,?a)')])
except ValueError: occurs=True
data={"solution":s1,"occurs_rejected":occurs,"ambiguous_example":"?a unconstrained"}
assert occurs and s1.get('?a')=='Nat'; emit('lab11_elaboration.json',data)
