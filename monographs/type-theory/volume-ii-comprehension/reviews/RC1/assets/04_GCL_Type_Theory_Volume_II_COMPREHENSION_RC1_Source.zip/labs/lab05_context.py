from __future__ import annotations
import json
from pathlib import Path
from comp_core import *
OUT=Path(__file__).resolve().parents[1]/"evidence"
OUT.mkdir(exist_ok=True)
def emit(name,data):
    p=OUT/name
    p.write_text(json.dumps(data,indent=2,sort_keys=True)+"\n")
    print(json.dumps(data,indent=2,sort_keys=True))
ctx=(("n",NatT()),("b",BoolT()),("i",FinT(Var('n'))))
def deps(ctx): return {x:sorted(T.fv()) for x,T in ctx}
def swappable(ctx,k):
    (x,A),(y,B)=ctx[k],ctx[k+1]
    return x not in B.fv() and y not in A.fv()
data={"well_formed":wf_context(ctx),"swap_n_b":swappable(ctx,0),"swap_b_i":swappable(ctx,1),"deps":deps(ctx)}
assert data['well_formed'] and data['swap_n_b'] and data['swap_b_i']; emit('lab05_context.json',data)
