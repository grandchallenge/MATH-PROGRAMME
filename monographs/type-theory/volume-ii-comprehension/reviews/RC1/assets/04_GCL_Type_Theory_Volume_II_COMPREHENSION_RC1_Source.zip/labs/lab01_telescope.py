from __future__ import annotations
import json
from pathlib import Path
from comp_core import *
OUT=Path(__file__).resolve().parents[1]/"evidence"
OUT.mkdir(exist_ok=True)
def emit(name,data):
    p=OUT/name
    p.write_text(json.dumps(data,indent=2,sort_keys=True)+"\n")
    print(json.dumps(data,indent=2,sort_keys=True))
ctx=(("n",NatT()),("i",FinT(Var("n"))))
bad=(("i",FinT(Var("n"))),("n",NatT()))
data={"accepted":wf_context(ctx),"rejected_reversed":not wf_context(bad),"dependency":"i->n"}
assert all(data.values())
emit('lab01_telescope.json',data)
