from __future__ import annotations
import json
from pathlib import Path
from comp_core import *
OUT=Path(__file__).resolve().parents[1]/"evidence"
OUT.mkdir(exist_ok=True)
def emit(name,data):
    p=OUT/name
    p.write_text(json.dumps(data,indent=2,sort_keys=True)+"\n")
    print(json.dumps(data,indent=2,sort_keys=True))
ctx=(("f",PiT('n',NatT(),FinT(Succ(Var('n'))))),)
app=synth(ctx,App(Var('f'),NatLit(1)))
lam_ok=check((),Lam('x',Var('x')),PiT('z',NatT(),NatT()))
failed=False
try: synth((),Lam('x',Var('x')))
except TypeError: failed=True
data={"application_type":str(app),"lambda_checks":lam_ok,"lambda_no_synthesis":failed}
assert lam_ok and failed; emit('lab10_checker.json',data)
