from __future__ import annotations
import json
from pathlib import Path
from comp_core import *
OUT=Path(__file__).resolve().parents[1]/"evidence"
OUT.mkdir(exist_ok=True)
def emit(name,data):
    p=OUT/name
    p.write_text(json.dumps(data,indent=2,sort_keys=True)+"\n")
    print(json.dumps(data,indent=2,sort_keys=True))
ctx=(("f",PiT("n",NatT(),FinT(Succ(Var("n"))))),)
T=synth(ctx,App(Var('f'),NatLit(2)))
beta=normalize(App(Lam('x',Succ(Var('x'))),NatLit(0)))
cap=Lam('y',Var('x')).subst('x',Var('y'))
data={"dependent_application":str(T)=="Fin(succ(2))","beta":str(beta)=="succ(0)","capture_avoided":str(cap).startswith('(lambda y1.')}
assert all(data.values()); emit('lab03_pi.json',data)
