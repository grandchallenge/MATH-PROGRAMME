from __future__ import annotations
import json
from pathlib import Path
from comp_core import *
OUT=Path(__file__).resolve().parents[1]/"evidence"
OUT.mkdir(exist_ok=True)
def emit(name,data):
    p=OUT/name
    p.write_text(json.dumps(data,indent=2,sort_keys=True)+"\n")
    print(json.dumps(data,indent=2,sort_keys=True))
decoded=[decode_code('natC'),decode_code('boolC'),decode_code(('prodC','natC','boolC')),decode_code(('vecC','natC',3))]
self_reject=False
try: decode_code('selfC')
except ValueError: self_reject=True
data={"decoded":decoded,"self_code_rejected":self_reject}
assert self_reject; emit('lab12_codes.json',data)
