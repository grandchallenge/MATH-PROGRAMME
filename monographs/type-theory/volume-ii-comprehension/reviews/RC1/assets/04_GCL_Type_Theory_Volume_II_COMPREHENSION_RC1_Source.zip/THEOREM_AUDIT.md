# Theorem Audit — Volume II: COMPREHENSION RC1

This audit is an internal mathematical-reader pass, not an independent referee report. Regression programs support executable examples; they do not mechanize the metatheory.

| Result | Exact scope | Dependencies / induction measure | Critical cases | RC1 status |
|---|---|---|---|---|
| Weakening under dependency | COMP-0 | induction on derivation + trailing-context formation | variable; `Fin(t)` formation; context extension | proof included |
| Generalized substitution | COMP-0, `Γ,x:A,Δ ⊢ J` | simultaneous induction on derivation/well-formed suffix | variable `x`; dependent `Fin(t)`; trailing declarations | proof included |
| Substitution composition | binder-free COMP-0 | structural induction on terms/types/context suffix | variable coincidences; `Fin(t)` | proof sketch + Lab 2 regression |
| Π formation/introduction/elimination | COMP-ΠΣ | formation premises explicitly scoped | codomain well-formed under binder; application substitution | rules included |
| Principal Π-beta subject reduction | COMP-ΠΣ principal beta redex | dependent substitution theorem | `(λx.t) a → t[a/x]` with result `B[a/x]` | proof included |
| Σ formation/introduction/projections | COMP-ΠΣ | formation + substitution/conversion | second projection `B(fst p)` | rules included |
| Principal Σ projection preservation | COMP-ΠΣ principal pair redexes | pair typing + definitional equality | `fst <a,b>`; `snd <a,b>` | proof included |
| Conditional adjacent exchange | COMP telescopes | mutual non-dependence + suffix re-formation | neither declaration may depend on the other | scoped proposition/proof sketch |
| Canonical `Fin` values | selected COMP-I `Fin` family | inversion on value typing derivation | no inhabitant form at index zero; successor constructor | proof sketch + Lab 6 |
| Canonical vector values | selected COMP-I `Vec` family | inversion on value typing derivation | zero vs successor index | proof sketch + Lab 7 |
| Nonempty vector head has no nil case | selected COMP-I | vector canonical forms | index `succ(n)` excludes `vnil` | formal example + Lab 8 |
| Bidirectional algorithmic soundness | explicit COMP-CHECK subset | induction on synth/check derivation | application substitution; lambda expected Π; pair expected Σ; conversion | proof sketch + Lab 10 regression |
| Checker termination | concrete teaching implementation only | structural recursion + terminating finite normalizer on admitted syntax | no general recursion; finite constraint search | implementation argument |
| Kernel trust-boundary proposition | explicit elaborator/core/checker architecture | checker soundness + exact emitted core | elaborator may fail/search incorrectly but cannot make rejected core valid | scoped proposition |
| Toy code decoder totality | finite external code grammar in Lab 12 | finite case split on code syntax | unsupported code rejected | executable result only |

## Explicitly not established

- Strong normalization for the full pedagogical union of fragments.
- Global canonicity without a cited/proved normalization route.
- Decidability/completeness of arbitrary dependent definitional equality.
- General strict-positivity or termination checking for user-defined inductive families.
- Consistency of a full internal universe hierarchy.
- Identity types, propositional equality, `J`, or general transport. Those belong to Volume VII.
- Completeness of elaboration or higher-order unification.

No argument in the manuscript may use one of these non-results as an unstated premise.
