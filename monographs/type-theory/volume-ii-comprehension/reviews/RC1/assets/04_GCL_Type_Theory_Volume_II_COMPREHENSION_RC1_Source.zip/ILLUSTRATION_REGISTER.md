# Illustration Register — Volume II: COMPREHENSION RC1

All 42 canonical plates are `FINISHED-RC1`. Each was rendered in the plate folio and inspected at manuscript scale. Connector routing plus `gcllabel` shielding is mandatory; no plate is permitted to obscure readable text.

## Plate 1 — FINISHED-RC1 — Fixed World / Dependent World
**Pedagogical burden:** A family judgment permits type formation to depend on an earlier term.
**Analogy/scope limit:** The fiber language is geometric intuition; no set-theoretic model is assumed.

## Plate 2 — FINISHED-RC1 — The Telescope
**Pedagogical burden:** Context order carries dependency information.
**Analogy/scope limit:** Arrows represent free-variable dependency, not runtime dataflow.

## Plate 3 — FINISHED-RC1 — Dependency Is Static Structure
**Pedagogical burden:** Type dependency is a formation discipline, not merely dynamic tagging.
**Analogy/scope limit:** Implementations may retain runtime evidence, but the judgments remain distinct.

## Plate 4 — FINISHED-RC1 — Substitution Rewrites the World
**Pedagogical burden:** Substitution specializes later declaration types as well as terms.
**Analogy/scope limit:** This is structural substitution, not evaluation.

## Plate 5 — FINISHED-RC1 — The Trailing Context
**Pedagogical burden:** The generalized theorem must account for dependent declarations after the substituted variable.
**Analogy/scope limit:** Well-formedness side conditions remain explicit.

## Plate 6 — FINISHED-RC1 — The Comprehension Loop
**Pedagogical burden:** Family formation and substitution form a recurring compositional cycle.
**Analogy/scope limit:** Formal derivations are trees; the loop is pedagogical organization.

## Plate 7 — FINISHED-RC1 — Pi as a Bundle of Codomains
**Pedagogical burden:** A dependent function chooses an output in the codomain selected by its input.
**Analogy/scope limit:** The bundle picture is intuition, not a claim about one particular semantic model.

## Plate 8 — FINISHED-RC1 — Constant Family: Pi Becomes Arrow
**Pedagogical burden:** The ordinary arrow is the constant-family specialization of dependent product in this presentation.
**Analogy/scope limit:** Other formalisms may take arrow as primitive rather than abbreviation.

## Plate 9 — FINISHED-RC1 — Application Specializes the Result
**Pedagogical burden:** Dependent application substitutes the argument into the codomain.
**Analogy/scope limit:** Type substitution is not runtime mutation.

## Plate 10 — FINISHED-RC1 — Sigma as a Fibered Pair
**Pedagogical burden:** A dependent pair packages an index with a payload in the selected family member.
**Analogy/scope limit:** The fiber picture is semantic intuition only.

## Plate 11 — FINISHED-RC1 — Constant Family: Sigma Becomes Product
**Pedagogical burden:** An ordinary product is the constant-family specialization of dependent sum here.
**Analogy/scope limit:** No cross-formalism claim of definitional identity is intended.

## Plate 12 — FINISHED-RC1 — The Second Projection Remembers the First
**Pedagogical burden:** The second projection has a type specialized by the first projection.
**Analogy/scope limit:** Dependency is typed structure, not object-oriented field lookup.

## Plate 13 — FINISHED-RC1 — Context Extension Is Comprehension
**Pedagogical burden:** A well-formed family extends a context and induces a projection back to the base.
**Analogy/scope limit:** The arrow is a semantic reading of syntactic structure, not an extra runtime operation.

## Plate 14 — FINISHED-RC1 — Exchange Is Conditional
**Pedagogical burden:** Dependent contexts admit exchange only when formation dependencies are preserved.
**Analogy/scope limit:** The diagram gives a sufficient condition, not every possible implementation optimization.

## Plate 15 — FINISHED-RC1 — Pi and Sigma Consume the Same Family
**Pedagogical burden:** Both major dependent formers are operations on the same family data.
**Analogy/scope limit:** Their introduction, elimination, and computation rules remain different.

## Plate 16 — FINISHED-RC1 — Fin as an Indexed Boundary
**Pedagogical burden:** Constructor result indices make the finite bound part of admissible construction.
**Analogy/scope limit:** The family encodes one bound invariant, not general program safety.

## Plate 17 — FINISHED-RC1 — Static Index / Runtime Representation
**Pedagogical burden:** Static role and runtime representation are distinct design questions.
**Analogy/scope limit:** The plate does not prescribe erasure or retention.

## Plate 18 — FINISHED-RC1 — Canonical Fin Values
**Pedagogical burden:** Finite-index values expose constructor shape constrained by the result index.
**Analogy/scope limit:** Canonical forms classify values; they do not prove termination.

## Plate 19 — FINISHED-RC1 — Vector Length in the Type
**Pedagogical burden:** Vector constructors refine the length index by construction.
**Analogy/scope limit:** Runtime layout may still coincide with ordinary lists.

## Plate 20 — FINISHED-RC1 — Impossible Constructor / Index Combinations
**Pedagogical burden:** Result indices rule out constructor shapes inconsistent with the claimed length.
**Analogy/scope limit:** The conclusion depends on the current definitional equality.

## Plate 21 — FINISHED-RC1 — Shape from the Index
**Pedagogical burden:** Canonical forms let an eliminator infer which constructor shapes remain possible.
**Analogy/scope limit:** This is inversion on values, not global evaluation behavior.

## Plate 22 — FINISHED-RC1 — Vector Head Needs No Empty Branch
**Pedagogical burden:** A nonempty vector type excludes the nil constructor before the head body is checked.
**Analogy/scope limit:** The guarantee is local to the represented invariant.

## Plate 23 — FINISHED-RC1 — Safe Lookup Aligns Two Indices
**Pedagogical burden:** Shared indices align vector shape with admissible positions.
**Analogy/scope limit:** The index does not certify external memory or foreign data.

## Plate 24 — FINISHED-RC1 — A Motive Preserves Dependency
**Pedagogical burden:** A motive states the result family of dependent elimination.
**Analogy/scope limit:** The plate suppresses the full constructor-specific eliminator rules.

## Plate 25 — FINISHED-RC1 — Conversion Through Definitional Equality
**Pedagogical burden:** Conversion permits typing across equal types according to the kernel equality.
**Analogy/scope limit:** Definitional equality is not arbitrary mathematical equality.

## Plate 26 — FINISHED-RC1 — Computation Can Expose Equal Indices
**Pedagogical burden:** Index computation can discharge type mismatches automatically.
**Analogy/scope limit:** Only the admitted computation rules contribute.

## Plate 27 — FINISHED-RC1 — Where Definitional Equality Runs Out
**Pedagogical burden:** Mathematical equality may exceed automatic definitional equality.
**Analogy/scope limit:** Identity types and explicit transport are deferred to Volume VII.

## Plate 28 — FINISHED-RC1 — Bidirectional Information Flow
**Pedagogical burden:** Bidirectional typing makes the direction of available information explicit.
**Analogy/scope limit:** It is an algorithmic presentation, not a new declarative truth relation.

## Plate 29 — FINISHED-RC1 — Application Synthesizes / Lambda Checks
**Pedagogical burden:** Applications can synthesize specialized codomains while lambdas use expected domains.
**Analogy/scope limit:** More complete inference procedures are possible but not assumed.

## Plate 30 — FINISHED-RC1 — Annotations Move Information
**Pedagogical burden:** An explicit annotation converts a checking obligation into a locally synthesizable type.
**Analogy/scope limit:** Annotations are evidence for the checker, not proof of correctness by themselves.

## Plate 31 — FINISHED-RC1 — Elaborator and Kernel
**Pedagogical burden:** Elaboration may be sophisticated while validity remains anchored in a smaller checker.
**Analogy/scope limit:** Kernel acceptance does not automatically prove faithful surface intent.

## Plate 32 — FINISHED-RC1 — Metavariables Carry Constraints
**Pedagogical burden:** A metavariable is a question constrained by uses, not an accepted proof term.
**Analogy/scope limit:** The teaching solver handles only first-order syntactic constraints.

## Plate 33 — FINISHED-RC1 — Three Elaboration Failures
**Pedagogical burden:** Elaboration failure has distinct causes that diagnostics should not collapse.
**Analogy/scope limit:** A production elaborator may expose additional failure classes.

## Plate 34 — FINISHED-RC1 — Codes and Decoding
**Pedagogical burden:** Universe codes make descriptions of types manipulable under controlled decoding.
**Analogy/scope limit:** The code language is not the set of all types.

## Plate 35 — FINISHED-RC1 — Why Type-in-Type Is Not Free
**Pedagogical burden:** Unrestricted self-classification requires justification and is not silently admitted.
**Analogy/scope limit:** The plate is a design warning, not a full paradox proof.

## Plate 36 — FINISHED-RC1 — Stratification Pressure
**Pedagogical burden:** Universe levels control how descriptions of types may themselves be classified.
**Analogy/scope limit:** Different type theories use different stratification policies.

## Plate 37 — FINISHED-RC1 — Formation Rules Build Worlds
**Pedagogical burden:** Changing formation rules changes which computational specifications can be stated directly.
**Analogy/scope limit:** Expressiveness does not automatically imply better engineering.

## Plate 38 — FINISHED-RC1 — Comprehension as a Display Map
**Pedagogical burden:** Categorical comprehension organizes context extension and reindexing.
**Analogy/scope limit:** A model validates syntax; syntax is not literally identical to one model.

## Plate 39 — FINISHED-RC1 — Expressiveness Has a Cost
**Pedagogical burden:** Richer dependency trades specification power against checking and elaboration burden.
**Analogy/scope limit:** The balance is architecture-dependent, not a universal numeric law.

## Plate 40 — FINISHED-RC1 — Volume II Synthesis
**Pedagogical burden:** Dependency propagates from formation through construction, elimination, equality, and checking.
**Analogy/scope limit:** The map is a conceptual dependency graph, not a proof implication graph.

## Plate 41 — FINISHED-RC1 — What Indices Cannot Guarantee
**Pedagogical burden:** Typed indices guarantee only what is encoded and preserved inside their trust assumptions.
**Analogy/scope limit:** Environmental and semantic correctness can require additional evidence.

## Plate 42 — FINISHED-RC1 — Threshold to Proof / Program
**Pedagogical burden:** Dependent construction creates the structural pressure for propositions-as-types.
**Analogy/scope limit:** The logical correspondence is previewed here, not yet established as a theorem.
