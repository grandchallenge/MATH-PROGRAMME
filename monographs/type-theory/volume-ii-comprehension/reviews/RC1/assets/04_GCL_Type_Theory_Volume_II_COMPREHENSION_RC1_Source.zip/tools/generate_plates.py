from pathlib import Path
root=Path('/mnt/data/type_theory_volume2_rc1/plates')
specs=[
(1,'Fixed World / Dependent World','Fixed type $B$','Index $x:A$','Family $B(x)$','A family judgment permits type formation to depend on an earlier term.','The fiber language is geometric intuition; no set-theoretic model is assumed.'),
(2,'The Telescope','$n:\\Nat$','$i:\\Fin(n)$','$j:\\Fin(\\mathrm{succ}(n))$','Context order carries dependency information.','Arrows represent free-variable dependency, not runtime dataflow.'),
(3,'Dependency Is Static Structure','family formation','typing judgment','runtime branch','Type dependency is a formation discipline, not merely dynamic tagging.','Implementations may retain runtime evidence, but the judgments remain distinct.'),
(4,'Substitution Rewrites the World','$n:\\Nat,\\ i:\\Fin(n)$','substitute $3/n$','$i:\\Fin(3)$','Substitution specializes later declaration types as well as terms.','This is structural substitution, not evaluation.'),
(5,'The Trailing Context','$\\Gamma,x:A,\\Delta$','$a:A$','$\\Gamma,\\Delta[a/x]$','The generalized theorem must account for dependent declarations after the substituted variable.','Well-formedness side conditions remain explicit.'),
(6,'The Comprehension Loop','form family','extend + construct','substitute + specialize','Family formation and substitution form a recurring compositional cycle.','Formal derivations are trees; the loop is pedagogical organization.'),
(7,'Pi as a Bundle of Codomains','$x:A$','$B(x)$','$f:\\Pi(x:A).B(x)$','A dependent function chooses an output in the codomain selected by its input.','The bundle picture is intuition, not a claim about one particular semantic model.'),
(8,'Constant Family: Pi Becomes Arrow','$\\Pi(x:A).B$','$x\\notin FV(B)$','$A\\to B$','The ordinary arrow is the constant-family specialization of dependent product in this presentation.','Other formalisms may take arrow as primitive rather than abbreviation.'),
(9,'Application Specializes the Result','$f:\\Pi(x:A).B(x)$','$a:A$','$f\\,a:B(a)$','Dependent application substitutes the argument into the codomain.','Type substitution is not runtime mutation.'),
(10,'Sigma as a Fibered Pair','$a:A$','$b:B(a)$','$\\langle a,b\\rangle:\\Sigma(x:A).B(x)$','A dependent pair packages an index with a payload in the selected family member.','The fiber picture is semantic intuition only.'),
(11,'Constant Family: Sigma Becomes Product','$\\Sigma(x:A).B$','$x\\notin FV(B)$','$A\\times B$','An ordinary product is the constant-family specialization of dependent sum here.','No cross-formalism claim of definitional identity is intended.'),
(12,'The Second Projection Remembers the First','$p:\\Sigma(x:A).B(x)$','$\\mathsf{fst}\,p:A$','$\\mathsf{snd}\,p:B(\\mathsf{fst}\,p)$','The second projection has a type specialized by the first projection.','Dependency is typed structure, not object-oriented field lookup.'),
(13,'Context Extension Is Comprehension','$\\Gamma$','$\\Gamma.A$','$\\pi_A:\\Gamma.A\\to\\Gamma$','A well-formed family extends a context and induces a projection back to the base.','The arrow is a semantic reading of syntactic structure, not an extra runtime operation.'),
(14,'Exchange Is Conditional','independent declarations','legal swap','dependency edge','Dependent contexts admit exchange only when formation dependencies are preserved.','The diagram gives a sufficient condition, not every possible implementation optimization.'),
(15,'Pi and Sigma Consume the Same Family','$\\Gamma\\vdash A\\type$','$\\Gamma,x:A\\vdash B\\type$','$\\Pi / \\Sigma$','Both major dependent formers are operations on the same family data.','Their introduction, elimination, and computation rules remain different.'),
(16,'Fin as an Indexed Boundary','$\\Fin(0)$','$\\Fin(1)$','$\\Fin(2)$','Constructor result indices make the finite bound part of admissible construction.','The family encodes one bound invariant, not general program safety.'),
(17,'Static Index / Runtime Representation','index in type','possible erased data','possible retained data','Static role and runtime representation are distinct design questions.','The plate does not prescribe erasure or retention.'),
(18,'Canonical Fin Values','$\\mathsf{fzero}$','$\\mathsf{fsucc}(i)$','$\\Fin(\\mathrm{succ}(n))$','Finite-index values expose constructor shape constrained by the result index.','Canonical forms classify values; they do not prove termination.'),
(19,'Vector Length in the Type','$\\mathsf{vnil}:\\Vec(A,0)$','$xs:\\Vec(A,n)$','$\\mathsf{vcons}(a,xs):\\Vec(A,\\mathrm{succ}(n))$','Vector constructors refine the length index by construction.','Runtime layout may still coincide with ordinary lists.'),
(20,'Impossible Constructor / Index Combinations','$\\mathsf{vnil}$','$\\Vec(A,0)$','$\\Vec(A,\\mathrm{succ}(n))$','Result indices rule out constructor shapes inconsistent with the claimed length.','The conclusion depends on the current definitional equality.'),
(21,'Shape from the Index','index $0$','index $\\mathrm{succ}(n)$','nil / cons inversion','Canonical forms let an eliminator infer which constructor shapes remain possible.','This is inversion on values, not global evaluation behavior.'),
(22,'Vector Head Needs No Empty Branch','$\\Vec(A,\\mathrm{succ}(n))$','constructor inversion','$A$','A nonempty vector type excludes the nil constructor before the head body is checked.','The guarantee is local to the represented invariant.'),
(23,'Safe Lookup Aligns Two Indices','$\\Vec(A,n)$','$\\Fin(n)$','lookup result $A$','Shared indices align vector shape with admissible positions.','The index does not certify external memory or foreign data.'),
(24,'A Motive Preserves Dependency','$i:I, x:F(i)$','$P(i,x)$','dependent eliminator','A motive states the result family of dependent elimination.','The plate suppresses the full constructor-specific eliminator rules.'),
(25,'Conversion Through Definitional Equality','$t:A$','$A\\equiv B$','$t:B$','Conversion permits typing across equal types according to the kernel equality.','Definitional equality is not arbitrary mathematical equality.'),
(26,'Computation Can Expose Equal Indices','beta/projection redex','normalize index','same family member','Index computation can discharge type mismatches automatically.','Only the admitted computation rules contribute.'),
(27,'Where Definitional Equality Runs Out','$n+0$','$n$','transport pressure','Mathematical equality may exceed automatic definitional equality.','Identity types and explicit transport are deferred to Volume VII.'),
(28,'Bidirectional Information Flow','synthesize $\\Rightarrow$','check $\\Leftarrow$','conversion boundary','Bidirectional typing makes the direction of available information explicit.','It is an algorithmic presentation, not a new declarative truth relation.'),
(29,'Application Synthesizes / Lambda Checks','function application','expected Pi type','lambda body','Applications can synthesize specialized codomains while lambdas use expected domains.','More complete inference procedures are possible but not assumed.'),
(30,'Annotations Move Information','$t$','$(t:A)$','$A$ synthesized','An explicit annotation converts a checking obligation into a locally synthesizable type.','Annotations are evidence for the checker, not proof of correctness by themselves.'),
(31,'Elaborator and Kernel','surface syntax','elaborator + constraints','explicit core / kernel','Elaboration may be sophisticated while validity remains anchored in a smaller checker.','Kernel acceptance does not automatically prove faithful surface intent.'),
(32,'Metavariables Carry Constraints','$?\\alpha$','constraints','candidate solution','A metavariable is a question constrained by uses, not an accepted proof term.','The teaching solver handles only first-order syntactic constraints.'),
(33,'Three Elaboration Failures','core invalid','search incomplete','ambiguous','Elaboration failure has distinct causes that diagnostics should not collapse.','A production elaborator may expose additional failure classes.'),
(34,'Codes and Decoding','$\\mathsf{natC}:\\mathcal U_0$','$\\El(\\mathsf{natC})$','$\\Nat$','Universe codes make descriptions of types manipulable under controlled decoding.','The code language is not the set of all types.'),
(35,'Why Type-in-Type Is Not Free','$\\mathsf{Type}:\\mathsf{Type}$','self-classification','paradox pressure','Unrestricted self-classification requires justification and is not silently admitted.','The plate is a design warning, not a full paradox proof.'),
(36,'Stratification Pressure','$\\mathcal U_0$','$\\mathcal U_1$','$\\mathcal U_2$','Universe levels control how descriptions of types may themselves be classified.','Different type theories use different stratification policies.'),
(37,'Formation Rules Build Worlds','simple formers','dependent formers','indexed formers','Changing formation rules changes which computational specifications can be stated directly.','Expressiveness does not automatically imply better engineering.'),
(38,'Comprehension as a Display Map','$\\Gamma.A$','$\\pi_A$','$\\Gamma$','Categorical comprehension organizes context extension and reindexing.','A model validates syntax; syntax is not literally identical to one model.'),
(39,'Expressiveness Has a Cost','more invariants','more equality/search','design trade-off','Richer dependency trades specification power against checking and elaboration burden.','The balance is architecture-dependent, not a universal numeric law.'),
(40,'Volume II Synthesis','family formation','indexed construction','checking + reflection','Dependency propagates from formation through construction, elimination, equality, and checking.','The map is a conceptual dependency graph, not a proof implication graph.'),
(41,'What Indices Cannot Guarantee','typed invariant','trusted boundary','external world','Typed indices guarantee only what is encoded and preserved inside their trust assumptions.','Environmental and semantic correctness can require additional evidence.'),
(42,'Threshold to Proof / Program','$\\Pi$ as universal shape','$\\Sigma$ as witness shape','Volume III','Dependent construction creates the structural pressure for propositions-as-types.','The logical correspondence is previewed here, not yet established as a theorem.'),
]

def esc_title(s): return s
for num,title,a,b,c,claim,limit in specs:
    variant=num%3
    if variant==1:
        body=rf'''\node[draw=GCLBlue,rounded corners=3pt,minimum width=3.2cm,minimum height=1.3cm,text width=2.8cm,align=center,gcllabel] (a) at (-4.2,0) {{{a}}};
\node[draw=GCLWarm,rounded corners=3pt,minimum width=3.2cm,minimum height=1.3cm,text width=2.8cm,align=center,gcllabel] (b) at (0,0) {{{b}}};
\node[draw=GCLGreen,rounded corners=3pt,minimum width=3.2cm,minimum height=1.3cm,text width=2.8cm,align=center,gcllabel] (c) at (4.2,0) {{{c}}};
\draw[gclbluearrow] (a.east) -- (b.west);
\draw[gclwarmarrow] (b.east) -- (c.west);'''
    elif variant==2:
        body=rf'''\node[draw=GCLBlue,rounded corners=3pt,minimum width=5.2cm,minimum height=1.15cm,text width=4.7cm,align=center,gcllabel] (a) at (0,1.75) {{{a}}};
\node[draw=GCLWarm,rounded corners=3pt,minimum width=5.2cm,minimum height=1.15cm,text width=4.7cm,align=center,gcllabel] (b) at (0,0) {{{b}}};
\node[draw=GCLGreen,rounded corners=3pt,minimum width=5.2cm,minimum height=1.15cm,text width=4.7cm,align=center,gcllabel] (c) at (0,-1.75) {{{c}}};
\draw[gclbluearrow] (a.south) -- (b.north);
\draw[gclwarmarrow] (b.south) -- (c.north);'''
    else:
        body=rf'''\node[draw=GCLBlue,rounded corners=3pt,minimum width=4.1cm,minimum height=1.45cm,text width=3.6cm,align=center,gcllabel] (a) at (-3.1,0.55) {{{a}}};
\node[draw=GCLGreen,rounded corners=3pt,minimum width=4.1cm,minimum height=1.45cm,text width=3.6cm,align=center,gcllabel] (c) at (3.1,0.55) {{{c}}};
\node[draw=GCLWarm,rounded corners=3pt,minimum width=3.5cm,minimum height=1.0cm,text width=3.1cm,align=center,gcllabel] (b) at (0,-1.7) {{{b}}};
\draw[gclbluearrow] (a.east) to[out=10,in=170] (c.west);
\draw[gclwarmarrow] (a.south) to[out=-70,in=180] (b.west);
\draw[gclwarmarrow] (b.east) to[out=0,in=-110] (c.south);'''
    tex=rf'''\begin{{figure}}[p]
\centering
\begin{{tikzpicture}}[gclplate]
\node[anchor=west,font=\sffamily\bfseries\Large,gcllabel,text width=11.3cm] at (-5.7,3.35) {{{title}}};
\draw[GCLWarm,line width=1pt] (-5.7,2.95)--(5.7,2.95);
{body}
\node[text width=10.5cm,align=center,font=\sffamily\footnotesize,gcllabel] at (0,-3.0) {{{claim}}};
\end{{tikzpicture}}
\caption{{\textbf{{Plate {num}. {title}.}} {claim} {limit}}}
\label{{plate:v2-{num:02d}}}
\end{{figure}}
'''
    (root/f'plate{num:02d}.tex').write_text(tex)
print('wrote',len(specs),'plates')
