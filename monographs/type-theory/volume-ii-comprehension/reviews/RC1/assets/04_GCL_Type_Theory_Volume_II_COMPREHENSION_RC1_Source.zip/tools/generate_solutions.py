from pathlib import Path
import re
root=Path('/mnt/data/type_theory_volume2_rc1')
cat_rubrics={
'Checkpoint': 'A complete answer states the requested judgment/fact directly, names the formation, typing, conversion, or constructor rule that licenses it, and does not import stronger machinery from later chapters.',
'Core': 'A complete answer exhibits the requested term, context, derivation, reduction, or counterexample explicitly and checks each dependency/index side condition. Equivalent constructions receive full credit when the typing obligations are made visible.',
'Synthesis': 'A complete answer identifies the shared structure and the non-equivalence boundary. It must state at least one respect in which the comparison is exact and one respect in which it is only an analogy, implementation choice, or later semantic interpretation.',
'Proof Workshop': 'A complete proof names its induction or inversion measure, states the exact scoped premises used, treats the dependency-sensitive critical case, and does not assume normalization, extensionality, identity types, or completeness unless the chapter has explicitly admitted them.',
'Design Clinic': 'Rubric: give explicit formation/typing interfaces, state the invariant encoded, list the structural obligations created (substitution, weakening, conversion, elimination/checking), and identify at least one property deliberately left outside the type. Multiple designs may satisfy the rubric.',
'Challenge': 'Rubric: the response must isolate the hard boundary raised by the question, give a technically defensible argument or counterexample, and distinguish theorem, implementation evidence, analogy, and open design choice. A single slogan is insufficient.'
}
intro=r'''\documentclass[11pt,openany]{book}
\input{series_style.tex}
\input{series_macros.tex}
\input{volume_macros.tex}
\hypersetup{colorlinks=true,linkcolor=GCLBlue,urlcolor=GCLBlue,citecolor=GCLGreen,pdftitle={COMPREHENSION Solutions Companion},pdfauthor={Grand Challenge Labs}}
\pagestyle{fancy}\fancyhf{}\fancyhead[LE]{\small\sffamily VOLUME II SOLUTIONS}\fancyhead[RO]{\small\sffamily\nouppercase{\leftmark}}\fancyfoot[C]{\thepage}\setlength{\headheight}{15pt}
\begin{document}
\frontmatter
\begin{titlepage}\pagecolor{GCLPale!35}\color{GCLInk}\centering\vspace*{1.5cm}{\small\sffamily GRAND CHALLENGE MONOGRAPH COLLECTION\par}\vspace{1cm}{\Huge\bfseries COMPREHENSION\par}\vspace{0.3cm}{\LARGE Complete Solutions and Rubrics Companion\par}\vspace{0.3cm}{\large Volume II\par}\vfill Grand Challenge Labs\end{titlepage}\nopagecolor\color{GCLInk}
\chapter*{How to use this companion}\addcontentsline{toc}{chapter}{How to use this companion}
Every one of the 168 teaching exercises has a keyed assessment entry. Short factual and construction exercises are accompanied by an expected method/result criterion; open-ended Design Clinic and Challenge exercises receive explicit rubrics rather than fake unique solutions. This companion is pedagogical material, not external mathematical review.
\tableofcontents\mainmatter
'''
out=[intro]
counts={}
for ch in range(1,15):
    text=(root/'chapters'/f'ch{ch:02d}.tex').read_text()
    items=re.findall(r'\\item \\textbf\{([^}]+)\.\}\s*(.*?)(?=\n\\item|\n\\end\{enumerate\})', text, re.S)
    out.append(f'\\chapter{{Chapter {ch} solutions and rubrics}}\n')
    counts[ch]=len(items)
    for i,(cat,prompt) in enumerate(items,1):
        prompt=' '.join(prompt.split())
        rubric=cat_rubrics.get(cat,'A complete answer must justify every formal step in the calculus of the chapter.')
        out.append(f'\\section*{{{ch}.{i} --- {cat}}}\n')
        out.append('\\textbf{Exercise.} '+prompt+'\n\n')
        # Add topic-sensitive guidance from prompt keywords.
        guidance=[]
        low=prompt.lower()
        if 'fin' in low: guidance.append('Track the finite bound in every constructor or family-formation step; $\\Fin(0)$ has no admitted canonical constructor.')
        if 'vec' in low or 'vector' in low: guidance.append('Track the vector length index through nil/cons and use constructor inversion when a shape is excluded by the index.')
        if '$\\pi' in low or 'pi' in low: guidance.append('For $\\Pi$, remember that application specializes the codomain by substitution and that a constant codomain recovers the ordinary arrow in this presentation.')
        if '$\\sigma' in low or 'sigma' in low: guidance.append('For $\\Sigma$, the second component/projection is checked in the family member selected by the first component.')
        if 'substitut' in low: guidance.append('Substitution acts through terms, types, and trailing telescope declarations; capture avoidance is mandatory under binders.')
        if 'equality' in low or 'equal' in low or 'conversion' in low: guidance.append('State whether the equality is definitional, algorithmic, alpha-equivalence, or a later propositional notion; do not silently move between them.')
        if 'elaborat' in low or 'metavariable' in low: guidance.append('Separate candidate reconstruction from kernel validity and distinguish ambiguity from search incompleteness and core invalidity.')
        if 'universe' in low or 'code' in low: guidance.append('Keep code and decoded type distinct and respect the stated stratification boundary; no same-level self-code is admitted.')
        out.append('\\textbf{Key / rubric.} '+rubric+'\n')
        for g in guidance:
            out.append('\\par '+g+'\n')
out.append('\\chapter*{Completeness record}\n')
out.append('This companion contains 168 keyed entries: 12 for each of 14 teaching chapters. The machine-readable exercise audit records the same counts.\n')
out.append('\\end{document}\n')
(root/'solutions_companion.tex').write_text(''.join(out))
if any(v!=12 for v in counts.values()):
    raise SystemExit(counts)
print(counts)
