#!/usr/bin/env python3
from pathlib import Path
import re, json, subprocess, sys
R=Path(__file__).resolve().parents[1]
errors=[]; warnings=[]
def req(cond,msg):
    if not cond: errors.append(msg)
# Required source/audits
required=['main.tex','solutions_companion.tex','series_style.tex','series_macros.tex','volume_macros.tex','VOLUME_PLAN.md','CLAIMS_LEDGER.md','THEOREM_AUDIT.md','ILLUSTRATION_REGISTER.md','BIBLIOGRAPHY_PLAN.md','BIBLIOGRAPHY_AUDIT.md','EXERCISE_AUDIT.json','WORKSET_STATE.json','plates_folio.tex']
for x in required:req((R/x).exists(),f'missing {x}')
chapters=sorted((R/'chapters').glob('ch*.tex')); req(len(chapters)==14,f'chapter count {len(chapters)} != 14')
plates=sorted((R/'plates').glob('plate*.tex')); req(len(plates)==42,f'plate count {len(plates)} != 42')
for p in plates:
    t=p.read_text(); req('gcllabel' in t,f'{p.name}: no text shield'); req('\\caption{' in t,f'{p.name}: no caption'); req('\\label{plate:' in t,f'{p.name}: no label')
mode_re=re.compile(r'\\item\s+\\textbf\{(Checkpoint|Core|Synthesis|Proof Workshop|Design Clinic|Challenge)\.\}')
total=0
for c in chapters:
    n=len(mode_re.findall(c.read_text())); total+=n; req(n==12,f'{c.name}: {n} exercises')
req(total==168,f'exercise total {total}')
sol=(R/'solutions_companion.tex').read_text(); req(len(re.findall(r'\\section\*\{\d+\.\d+ ---',sol))==168,'solutions/rubric entry count != 168')
labfiles=sorted((R/'labs').glob('lab[0-9][0-9]_*.py')); req(len(labfiles)==14,f'lab count {len(labfiles)}')
evfiles=sorted((R/'evidence').glob('lab[0-9][0-9]_*.json')); req(len(evfiles)==14,f'lab evidence count {len(evfiles)}')
reg=json.loads((R/'evidence'/'PUBLICATION_REGRESSION.json').read_text()); req(reg.get('all_pass') is True and reg.get('passed')==14,'publication regression not 14/14')
ea=json.loads((R/'EXERCISE_AUDIT.json').read_text()); req(ea.get('complete_for_volume') and ea.get('total_exercises')==168 and ea.get('total_solutions_or_rubrics')==168,'exercise audit incomplete')
state=json.loads((R/'WORKSET_STATE.json').read_text()); req(state.get('requires_chat_history') is False,'workset not fresh-session safe')
# release forbids obvious unfinished markers in authored source; publication audit itself may mention gates, so exclude it.
bad=re.compile(r'\b(TODO|TBD|FIXME)\b',re.I)
for p in list(R.glob('*.tex'))+chapters+plates+labfiles:
    if bad.search(p.read_text(errors='ignore')): errors.append(f'unfinished marker: {p.relative_to(R)}')
print(json.dumps({'chapters':len(chapters),'plates':len(plates),'exercises':total,'solutions_or_rubrics':168,'labs':len(labfiles),'errors':errors,'warnings':warnings},indent=2))
sys.exit(1 if errors else 0)
