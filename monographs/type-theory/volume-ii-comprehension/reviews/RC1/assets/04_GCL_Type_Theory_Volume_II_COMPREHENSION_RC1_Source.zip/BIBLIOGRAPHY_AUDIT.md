# Bibliography Audit — Volume II: COMPREHENSION RC1

Metadata below was checked during the RC1 publication pass. This audit supports attribution; it is not a literature-novelty review.

| Work / attribution | Verified metadata | Evidence note |
|---|---|---|
| Martin-Löf, *Intuitionistic Type Theory* | Bibliopolis, Napoli, 1984; 91 pp.; notes/editorial role by Giovanni Sambin | Google Books / WorldCat / DBLP records agree on 1984 Bibliopolis edition |
| de Bruijn, AUTOMATH chapter | “The mathematical language AUTOMATH, its usage and some of its extensions,” LNM 125, Springer, 1970, pp. 29–61, DOI `10.1007/BFb0060623` | Eindhoven TU research portal and Springer proceedings metadata |
| Cartmell, contextual categories | D.Phil thesis, Oxford, 1978; later journal article *Annals of Pure and Applied Logic* 32 (1986), 209–243, DOI `10.1016/0168-0072(86)90053-9` | thesis scan identifies 1978 D.Phil; ScienceDirect verifies 1986 article |
| Coquand–Huet, Calculus of Constructions | *Information and Computation* 76(2–3), 1988, 95–120, DOI `10.1016/0890-5401(88)90005-3` | ScienceDirect metadata |
| Dybjer, “Inductive families” | *Formal Aspects of Computing* 6(4), 1994, 440–465, DOI `10.1007/BF01211308` | bibliographic record checked |
| Nordström–Petersson–Smith | *Programming in Martin-Löf’s Type Theory: An Introduction*, Clarendon Press, 1990, 221 pp. | Google Books / author-hosted record |
| Hofmann, dependent syntax/semantics | in Pitts & Dybjer (eds.), *Semantics and Logics of Computation*, CUP, 1997, pp. 79–130, DOI `10.1017/CBO9780511526619.004` | Cambridge Core metadata |
| Jacobs, categorical logic/type theory | *Categorical Logic and Type Theory*, Studies in Logic 141, Elsevier, 1999 | Elsevier / Google Books metadata |

## Historical claim boundary

The manuscript does not claim a unique inventor of dependent types, Π/Σ notation, comprehension categories, or universe methodology. Dates are used only for the cited publication records above.
