# RC1 Source Contents

Rebuild entry points: `main.tex`, `solutions_companion.tex`, `plates_folio.tex`.

Executable audit: `python labs/run_all.py` then `python tools/validate_rc1.py`.

The archive includes all chapter sources, 42 plate sources, 14 chapter laboratories, machine-readable evidence, style/macros, the claims/theorem/exercise/bibliography/illustration/publication audits, durable workset state, and generation/validation utilities. It intentionally excludes temporary render directories and LaTeX auxiliary/log files.
